/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


package org.pittsfordrobotics.yr2013;
import edu.wpi.first.wpilibj.Jaguar;

/**
 *
 * @author Liam Middlebrook
 */
public class Hardware {
    static Jaguar driveMotor1;
    static Jaguar driveMotor2;
    static Jaguar driveMotor3;
    static Jaguar driveMotor4;
}
